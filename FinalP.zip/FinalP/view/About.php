<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <link rel="stylesheet" href="../css/style4.css">
    </head>
<body>
<form action="../view/home.php"><input type="submit" value="Back" ></form>

    <h1>Information about the<br> member of<br> E-Passport Management System </h1>
<div class="cover">
    <div class="box">
        <img src="../css/Admin.jpg">
        <h2>Imran Hossain</h2>
        <p>Admin of our System</p>
</div>
<div class="box1">
        <img src="../css/manager.jpg">
        <h2>A.M Muftarin</h2>
        <p>Manager of our System</p>
</div>
<div class="box2">
        <img src="../css/nidhi.jpg">
        <h2>Samiya Shahid</h2>
        <p>Manufacturer of our System</p>
</div>
<div class="box">
        <img src="../css/user.jpg">
        <h2>Anik Kumar Das</h2>
        <p>First User of our System</p>
</div>
</div>
<form action="../view/home.php"><input type="submit" value="Back" ></form>

</body>
</html>
