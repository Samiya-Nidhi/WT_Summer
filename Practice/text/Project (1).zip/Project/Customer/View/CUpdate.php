<!DOCTYPE html>
    <head>
        <title>
            Profile Update
	    </title>
    </head>
    <body>
        <h1 align="center">
            24/7-Internet Service Provider
        </h1>
        <hr>
            <form action="" method="post">
                <h2 align="center"> Update your profile </h2>
                                    <table align="center">
                                        <tr>
                                            <td>Edit name:</td>
                                            <td><input type="text" name="Cname"placeholder="Enter your name">
                                            <td>
                                            </td>
                                            </td>
                                        </tr>
                                        <tr>
			                                <td>Edit E-mail:</td>
		                                    <td><input type="email" name="Cemail"placeholder="Enter your email"></td>
                                            <td>
                                            </td>
		                                </tr>
				                        <tr>
			                                <td>Edit Date of birth:</td>
		                                    <td><input type="date" name="Cdob"></td>
                                            <td>
                                            </td>
		                                </tr> 
                                        <tr>
			                                <td>Edit Gender:</td>
		                                    <td>
                                                <input type="radio" name="Cgender" value="Male">Male
                                                <input type="radio" name="Cgender"value="Female">Female
                                            </td>
                                            <td>
                                            </td>
		                                </tr>  
			                            <tr>
			                                <td> Edit Phone no:</td>
		                                    <td><input type="number" name="Cphn" placeholder="Enter your phone no."> </td>
                                            <td>
                                            </td>
		                                </tr> 
		                                <tr>
			                                <td> Edit City:</td>
		                                    <td><input type="text" name="Ccity" placeholder="Enter your city"> </td>
                                            <td>
                                            </td>
		                                </tr>
		                                <tr>
		    	                            <td>Edit Address:</td>
		    	                            <td><textarea name="Caddress" cols="21" rows="4"placeholder="Enter your full address"></textarea></td>
                                            <td>
                                            </td>
		                                </tr> 
                                        <tr>
		    	                            <td>Edit Password:</td>
		    	                            <td><input type="password" name="Cpass"></td>
                                            <td>
                                            </td> 
		                                </tr>
                                        <tr>
                                            <td></td>
                                            <td>
                                                <br/>
                                                <input type = "submit" name = "CSubmit" value = "Update">
                                                <input type = "reset" value = "Reset">
                    </tr>
                </table>
                <h4 align="center">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     Back to <a href="CProfile.php">Profile</a>
                </h4>
            </form>
        </hr>
    </body>
</html>